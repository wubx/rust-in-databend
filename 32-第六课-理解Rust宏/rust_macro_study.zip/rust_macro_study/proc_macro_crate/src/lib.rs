// 属性性过程宏
#[proc_macro_attribute]
pub fn return_self(_attrs: proc_macro::TokenStream, _input: proc_macro::TokenStream)
    -> proc_macro::TokenStream
{
    //eprintln!("{:#?}", attrs);
    //eprintln!("{:#?}", input);
   proc_macro::TokenStream::new() 
}

// 派生式过程宏
#[proc_macro_derive(AnswerFn)]
pub fn derive_answer_fn(_iten: proc_macro::TokenStream) -> proc_macro::TokenStream {
    "fn answer() -> i32 {100}".parse().unwrap()
    //proc_macro::TokenStream::new()
}

// 函数式过程宏
#[proc_macro]
pub fn make_answer_fn(input: proc_macro::TokenStream) -> proc_macro::TokenStream {
    "fn answer() -> i32 {200}".parse().unwrap()
    //proc_macro::TokenStream::new()
}











