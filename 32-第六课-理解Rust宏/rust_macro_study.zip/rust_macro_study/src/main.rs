//use proc_macro_crate::return_self;
//use proc_macro_crate::AnswerFn;
use proc_macro_crate::make_answer_fn;

//#[return_self("dssssflkdjslfkjdl")]
//fn answer() {
    //println!("run answer()");
//}


//#[derive(AnswerFn)]
//struct Student;

make_answer_fn!();


fn main() {
    println!("{}", answer());
    println!("Hello, world!");
}
