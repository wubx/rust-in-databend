// #[tokio::main] //此处引入tokio 宏/macro
// async fn main() {
//     println!("hello world!");
// }

// 通过宏展开.

fn main() {
    let runtime = tokio::runtime::Builder::new_multi_thread()
        .enable_all()
        .build()
        .expect("Failed building the Runtime");

    runtime.block_on(
        async {
            future.await

        }
    );
}

// fn main() {
//     let runtime = tokio::runtime::Builder::new_multi_thread()
//         .enable_all()
//         .build()
//         .expect("Failed building the Runtime");
//
//     runtime.block_on(
//         async {
//             println!("Hello World!");
//         }
//     );
// }