#![feature(generators, generator_trait)]
use std::ops::{Generator, GeneratorState};
use std::pin::Pin;
enum __Gen {
    // (0) 初始状态
    Start,
    // (1) resume 方法执行之后
    State1(State1),
    // (2) resume 方法执行之后
    State2(State2),
    // (3) resume 方法执行之后
    State3(State3),
    // (4) resume 方法执行之后
    Done
}
struct State1 {x: u64}
struct State2 {x: u64}
struct State3 {x: u64}
impl Generator for __Gen {
    type Yield = u64;
    type Return = u64;

    fn resume(self: Pin<&mut Self>, _: ()) -> GeneratorState<u64, u64> {
        let mut_ref = self.get_mut();
        match std::mem::replace(mut_ref, __Gen::Done) {
            __Gen::Start =>
                {
                *mut_ref = __Gen::State1(State1 { x: 1 });
                GeneratorState::Yielded(1)
            }
            __Gen::State1(State1 { x: 1 }) => {
                *mut_ref = __Gen::State2(State2 { x: 2 });
                GeneratorState::Yielded(2)
            }
            __Gen::State2(State2 { x: 2 }) => {
                *mut_ref = __Gen::State3(State3 { x: 3 });
                GeneratorState::Yielded(3)
            }
            __Gen::State3(State3 { x: 3 }) => {
                *mut_ref = __Gen::Done;
                GeneratorState::Complete(4)
            }
            _ => {
                panic!("generator resumed after completion")
            }
        }
    }
}

fn main() {
    let mut gen = {
        __Gen::Start
    };

    for _ in 0..1 {
        println!("{:?}", unsafe{Pin::new(&mut gen).resume(())});
    }
}