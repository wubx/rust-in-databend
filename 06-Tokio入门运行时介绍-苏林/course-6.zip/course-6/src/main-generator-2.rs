#![feature(generators, generator_trait)]
use std::pin::Pin;
use std::ops::{Generator, GeneratorState};

fn main() {
    let mut gen = || {
        println!("执行第1次yield");
        yield 1;
        println!("执行第2次yield");
        yield 2;
        println!("执行第3次yield");
        yield 3;
        println!("执行第4次yield");
        return 4;
    };

    if let GeneratorState::Yielded(v) = Pin::new(&mut gen).resume(()) {
        println!("resume {:?} : Pending", v);
    }

    if let GeneratorState::Yielded(v) = Pin::new(&mut gen).resume(()) {
        println!("resume {:?} : Pending", v);
    }

    if let GeneratorState::Yielded(v) = Pin::new(&mut gen).resume(()) {
        println!("resume {:?} : Pending", v);
    }

    if let GeneratorState::Complete(v) = Pin::new(&mut gen).resume(()) {
        println!("resume {:?} : Ready", v);
    }
}
